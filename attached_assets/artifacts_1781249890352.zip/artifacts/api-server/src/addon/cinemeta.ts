import axios from "axios";
import { cache, TTL } from "./cache.js";
import { logger } from "../lib/logger.js";

const CINEMETA_BASE = "https://v3-cinemeta.strem.io";
const CINEMETA_LIVE = "https://cinemeta-live.strem.io";
const TMDB_API = "https://api.themoviedb.org/3";
const TMDB_KEY = "1865f43a0549ca50d341dd9ab8b29f49";

export interface CinemetaMeta {
  id: string;
  type: string;
  name: string;
  year?: string | number;
  genres?: string[];
  poster?: string;
  background?: string;
  description?: string;
  imdbRating?: string;
  videos?: CinemetaVideo[];
}

export interface CinemetaVideo {
  id: string;
  title: string;
  season: number;
  episode: number;
  released?: string;
}

async function fetchCinemetaUrl(url: string): Promise<CinemetaMeta | null> {
  try {
    const res = await axios.get<{ meta: CinemetaMeta }>(url, {
      timeout: 8000,
      maxRedirects: 5,
    });
    const meta = res.data?.meta;
    if (meta?.name) return meta;
  } catch {
    // fall through
  }
  return null;
}

async function fetchFromTmdb(
  type: "movie" | "series",
  imdbId: string,
): Promise<CinemetaMeta | null> {
  try {
    const findRes = await axios.get<{
      movie_results: { id: number; title?: string; release_date?: string; poster_path?: string; overview?: string }[];
      tv_results: { id: number; name?: string; first_air_date?: string; poster_path?: string; overview?: string }[];
    }>(
      `${TMDB_API}/find/${imdbId}?api_key=${TMDB_KEY}&external_source=imdb_id`,
      { timeout: 8000 },
    );

    const isMovie = type === "movie";
    const result = isMovie
      ? findRes.data.movie_results?.[0]
      : findRes.data.tv_results?.[0];

    if (!result) return null;

    const name = isMovie
      ? (result as { title?: string }).title
      : (result as { name?: string }).name;
    if (!name) return null;

    const dateRaw = isMovie
      ? (result as { release_date?: string }).release_date
      : (result as { first_air_date?: string }).first_air_date;
    const year = dateRaw?.slice(0, 4);
    const poster = result.poster_path
      ? `https://image.tmdb.org/t/p/w500${result.poster_path}`
      : undefined;

    return {
      id: imdbId,
      type,
      name,
      year,
      poster,
      description: result.overview,
    };
  } catch (err) {
    logger.warn({ imdbId, type, err }, "TMDB fallback fetch failed");
  }
  return null;
}

export async function getMetaFromCinemeta(
  type: "movie" | "series",
  imdbId: string,
): Promise<CinemetaMeta | null> {
  const cacheKey = `cinemeta:meta:${type}:${imdbId}`;
  const cached = cache.get<CinemetaMeta>(cacheKey);
  if (cached) return cached;

  const urls = [
    `${CINEMETA_BASE}/meta/${type}/${imdbId}.json`,
    `${CINEMETA_LIVE}/meta/${type}/${imdbId}.json`,
  ];

  for (const url of urls) {
    const meta = await fetchCinemetaUrl(url);
    if (meta) {
      cache.set(cacheKey, meta, TTL.META);
      return meta;
    }
  }

  const tmdbMeta = await fetchFromTmdb(type, imdbId);
  if (tmdbMeta) {
    logger.info({ imdbId, type, name: tmdbMeta.name }, "Used TMDB fallback for meta");
    cache.set(cacheKey, tmdbMeta, TTL.META);
    return tmdbMeta;
  }

  logger.warn({ imdbId, type }, "Meta not found in Cinemeta or TMDB");
  return null;
}

export async function searchCinemeta(
  type: "movie" | "series",
  query: string,
): Promise<CinemetaMeta[]> {
  const cacheKey = `cinemeta:search:${type}:${query.toLowerCase()}`;
  const cached = cache.get<CinemetaMeta[]>(cacheKey);
  if (cached) return cached;

  try {
    const encoded = encodeURIComponent(query);
    const res = await axios.get<{ metas: CinemetaMeta[] }>(
      `${CINEMETA_BASE}/catalog/${type}/top/search=${encoded}.json`,
      { timeout: 8000, maxRedirects: 5 },
    );
    const metas = res.data?.metas ?? [];
    cache.set(cacheKey, metas, TTL.SEARCH);
    return metas;
  } catch (err) {
    logger.warn({ type, query, err }, "Cinemeta search failed");
  }
  return [];
}

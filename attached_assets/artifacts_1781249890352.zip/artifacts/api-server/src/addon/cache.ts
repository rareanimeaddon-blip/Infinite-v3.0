interface CacheEntry<T> {
  value: T;
  expiresAt: number;
}

class TTLCache {
  private store = new Map<string, CacheEntry<unknown>>();

  set<T>(key: string, value: T, ttlMs: number): void {
    this.store.set(key, { value, expiresAt: Date.now() + ttlMs });
  }

  get<T>(key: string): T | null {
    const entry = this.store.get(key);
    if (!entry) return null;
    if (Date.now() > entry.expiresAt) {
      this.store.delete(key);
      return null;
    }
    return entry.value as T;
  }

  has(key: string): boolean {
    return this.get(key) !== null;
  }

  delete(key: string): void {
    this.store.delete(key);
  }

  clear(): void {
    this.store.clear();
  }
}

export const cache = new TTLCache();

export const TTL = {
  CATALOG: 30 * 60 * 1000,
  META: 6 * 60 * 60 * 1000,
  STREAM: 10 * 60 * 1000,
  SEARCH: 2 * 60 * 60 * 1000,
  RESOLVE: 24 * 60 * 60 * 1000,
  RESOLVE_TOKEN: 8 * 60 * 1000,
};

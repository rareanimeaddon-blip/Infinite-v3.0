export const manifest = {
  id: "community.hdhub4u-4khdhub-combined",
  version: "2.0.0",
  name: "4KHDHub + HDHub4U",
  description:
    "Stremio addon serving streams from 4KHDHub and HDHub4U. Supports movies and series in 4K, 1080p, 720p with Hindi/Dual Audio. Compatible with IMDb, TMDB and Cinemeta.",
  logo: "https://i.imgur.com/D8wT8oL.png",
  background: "https://i.imgur.com/hqK6NWs.png",
  contactEmail: "addon@example.com",

  resources: [
    "catalog",
    {
      name: "stream",
      types: ["movie", "series"],
      idPrefixes: ["tt"],
    },
  ],

  types: ["movie", "series"],

  catalogs: [
    {
      type: "movie" as const,
      id: "4khdhub_movies",
      name: "4KHDHub Movies",
      extra: [
        { name: "skip", isRequired: false },
        { name: "search", isRequired: false },
      ],
    },
    {
      type: "series" as const,
      id: "4khdhub_series",
      name: "4KHDHub Series",
      extra: [
        { name: "skip", isRequired: false },
        { name: "search", isRequired: false },
      ],
    },
    {
      type: "movie" as const,
      id: "hdhub4u_movies",
      name: "HDHub4U Movies",
      extra: [
        { name: "skip", isRequired: false },
        { name: "search", isRequired: false },
      ],
    },
    {
      type: "series" as const,
      id: "hdhub4u_series",
      name: "HDHub4U Series",
      extra: [
        { name: "skip", isRequired: false },
        { name: "search", isRequired: false },
      ],
    },
  ],

  idPrefixes: ["tt"],

  behaviorHints: {
    adult: false,
    p2p: false,
    configurable: false,
  },
} as const;

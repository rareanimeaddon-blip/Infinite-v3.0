import { Router } from "express";
import { manifest } from "./manifest.js";
import { catalogHandler } from "./handlers/catalog.js";
import { streamHandler } from "./handlers/stream.js";
import { logger } from "../lib/logger.js";

const router = Router();

router.use((_req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
  if (process.env["NODE_ENV"] !== "production") {
    res.setHeader("Cache-Control", "no-cache, no-store");
  } else {
    res.setHeader("Cache-Control", "max-age=300, public");
  }
  next();
});

router.options("/{*path}", (_req, res) => {
  res.sendStatus(200);
});

router.get("/", (_req, res) => {
  const host = _req.get("host") ?? "";
  const proto = _req.headers["x-forwarded-proto"] ?? _req.protocol;
  const installUrl = `${proto}://${host}/api/addon/manifest.json`;
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1"/>
      <title>${manifest.name} — Stremio Addon</title>
      <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #0f0f0f; color: #fff; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 2rem; }
        .card { background: #1a1a1a; border-radius: 16px; padding: 2.5rem; max-width: 540px; width: 100%; text-align: center; box-shadow: 0 8px 32px rgba(0,0,0,0.4); }
        .logo { font-size: 3rem; margin-bottom: 1rem; }
        h1 { font-size: 1.5rem; font-weight: 700; margin-bottom: 0.5rem; color: #fff; }
        p { color: #888; margin-bottom: 2rem; line-height: 1.5; font-size: 0.9rem; }
        .install-btn { display: inline-block; background: #7c3aed; color: #fff; font-weight: 600; padding: 0.875rem 2rem; border-radius: 8px; text-decoration: none; font-size: 1rem; transition: background 0.2s; }
        .install-btn:hover { background: #6d28d9; }
        .url-box { margin-top: 1.5rem; background: #0f0f0f; border-radius: 8px; padding: 0.75rem 1rem; font-size: 0.75rem; color: #aaa; word-break: break-all; user-select: all; cursor: text; }
        .url-label { font-size: 0.7rem; color: #555; margin-bottom: 0.25rem; }
        .badges { display: flex; flex-wrap: wrap; justify-content: center; gap: 0.5rem; margin-top: 1.5rem; }
        .badge { background: #2a2a2a; color: #aaa; padding: 0.25rem 0.75rem; border-radius: 100px; font-size: 0.75rem; }
      </style>
    </head>
    <body>
      <div class="card">
        <div class="logo">🎬</div>
        <h1>${manifest.name}</h1>
        <p>${manifest.description}</p>
        <a href="stremio://${host}/api/addon/manifest.json" class="install-btn">Install in Stremio</a>
        <div class="url-label" style="margin-top:1.5rem;color:#555;font-size:.7rem;">Manifest URL (copy &amp; paste into Stremio)</div>
        <div class="url-box">${installUrl}</div>
        <div class="badges">
          <span class="badge">Movies</span>
          <span class="badge">Series</span>
          <span class="badge">IMDb</span>
          <span class="badge">TMDB</span>
          <span class="badge">Cinemeta</span>
          <span class="badge">4K • 1080p • 720p</span>
          <span class="badge">Hindi • Dual Audio</span>
        </div>
      </div>
    </body>
    </html>
  `);
});

router.get("/manifest.json", (_req, res) => {
  res.json(manifest);
});

router.get("/catalog/:type/:id.json", async (req, res) => {
  const { type, id } = req.params as { type: string; id: string };
  const extra = req.query as Record<string, string>;

  if (type !== "movie" && type !== "series") {
    res.json({ metas: [] });
    return;
  }

  logger.info({ type, id, extra }, "Catalog request");

  try {
    const result = await catalogHandler(type as "movie" | "series", id, extra);
    res.json(result);
  } catch (err) {
    logger.error({ err, type, id }, "Catalog handler error");
    res.json({ metas: [] });
  }
});

router.get("/catalog/:type/:id/:extra.json", async (req, res) => {
  const { type, id, extra: extraStr } = req.params as {
    type: string;
    id: string;
    extra: string;
  };

  if (type !== "movie" && type !== "series") {
    res.json({ metas: [] });
    return;
  }

  const extra: Record<string, string> = {};
  for (const part of decodeURIComponent(extraStr).split("&")) {
    const [k, v] = part.split("=");
    if (k && v !== undefined) extra[k] = v;
  }

  logger.info({ type, id, extra }, "Catalog (extra) request");

  try {
    const result = await catalogHandler(type as "movie" | "series", id, extra);
    res.json(result);
  } catch (err) {
    logger.error({ err, type, id }, "Catalog (extra) handler error");
    res.json({ metas: [] });
  }
});

router.get("/stream/:type/:id.json", async (req, res) => {
  const { type, id } = req.params as { type: string; id: string };

  if (type !== "movie" && type !== "series") {
    res.json({ streams: [] });
    return;
  }

  logger.info({ type, id }, "Stream request");

  try {
    const result = await streamHandler(type as "movie" | "series", id);
    res.json(result);
  } catch (err) {
    logger.error({ err, type, id }, "Stream handler error");
    res.json({ streams: [] });
  }
});

export default router;

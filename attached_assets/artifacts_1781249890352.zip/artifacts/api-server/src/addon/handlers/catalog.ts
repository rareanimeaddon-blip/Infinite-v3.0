import * as hub4k from "../scrapers/4khdhub.js";
import * as hdhub from "../scrapers/hdhub4u.js";
import { searchCinemeta, type CinemetaMeta } from "../cinemeta.js";
import { cache, TTL } from "../cache.js";
import { logger } from "../../lib/logger.js";

interface MetaPreview {
  id: string;
  type: "movie" | "series";
  name: string;
  poster?: string;
  year?: string;
  description?: string;
  genres?: string[];
  imdbRating?: string;
}

export interface ImdbPageMapping {
  site: "4khdhub" | "hdhub4u";
  url: string;
  scraperTitle: string;
}

export function getImdbPageMappings(imdbId: string): ImdbPageMapping[] {
  return cache.get<ImdbPageMapping[]>(`imdb2page:${imdbId}`) ?? [];
}

function addImdbPageMapping(imdbId: string, mapping: ImdbPageMapping): void {
  const existing = cache.get<ImdbPageMapping[]>(`imdb2page:${imdbId}`) ?? [];
  const alreadyExists = existing.some((m) => m.site === mapping.site && m.url === mapping.url);
  if (!alreadyExists) {
    existing.push(mapping);
    cache.set(`imdb2page:${imdbId}`, existing, TTL.META);
  }
}

async function resolveImdbId(
  title: string,
  year: string | undefined,
  type: "movie" | "series",
): Promise<CinemetaMeta | null> {
  const cacheKey = `imdb:resolve:${type}:${title.toLowerCase()}:${year ?? ""}`;
  const cached = cache.get<CinemetaMeta>(cacheKey);
  if (cached) return cached;

  try {
    const results = await searchCinemeta(type, title);
    if (results.length === 0) return null;

    let best = results[0]!;
    if (year) {
      const yearMatch = results.find(
        (r) => r.year && String(r.year) === String(year),
      );
      if (yearMatch) best = yearMatch;
    }

    const titleLower = title.toLowerCase().replace(/[^a-z0-9]/g, "");
    const nameLower = best.name?.toLowerCase().replace(/[^a-z0-9]/g, "");
    if (!nameLower?.includes(titleLower.slice(0, 6)) && !titleLower.includes(nameLower?.slice(0, 6) ?? "")) {
      return null;
    }

    cache.set(cacheKey, best, TTL.META);
    return best;
  } catch (err) {
    logger.warn({ title, year, err }, "resolveImdbId failed");
    return null;
  }
}

type CatalogSource = "4khdhub_movies" | "4khdhub_series" | "hdhub4u_movies" | "hdhub4u_series";

function siteFromCatalogId(catalogId: CatalogSource): "4khdhub" | "hdhub4u" {
  return catalogId.startsWith("4khdhub") ? "4khdhub" : "hdhub4u";
}

async function getItems(
  catalogId: CatalogSource,
  type: "movie" | "series",
  page: number,
  search?: string,
): Promise<hub4k.ScrapeItem[]> {
  if (search) {
    const [r1, r2] = await Promise.all([
      catalogId.startsWith("4khdhub") ? hub4k.searchSite(search) : Promise.resolve([] as hub4k.ScrapeItem[]),
      catalogId.startsWith("hdhub4u") ? hdhub.searchSite(search) : Promise.resolve([] as hdhub.ScrapeItem[]),
    ]);
    return [...r1, ...r2];
  }

  if (catalogId === "4khdhub_movies") return hub4k.fetchListing("movie", page);
  if (catalogId === "4khdhub_series") return hub4k.fetchListing("series", page);
  if (catalogId === "hdhub4u_movies") return hdhub.fetchListing("movie", page);
  if (catalogId === "hdhub4u_series") return hdhub.fetchListing("series", page);
  return [];
}

export async function catalogHandler(
  type: "movie" | "series",
  catalogId: string,
  extra: Record<string, string>,
): Promise<{ metas: MetaPreview[] }> {
  const skip = extra["skip"] ? parseInt(extra["skip"]) : 0;
  const search = extra["search"];
  const PAGE_SIZE = 20;
  const page = Math.floor(skip / PAGE_SIZE) + 1;

  const cacheKey = `catalog:${catalogId}:${type}:${page}:${search ?? ""}`;
  const cached = cache.get<{ metas: MetaPreview[] }>(cacheKey);
  if (cached) return cached;

  const items = await getItems(catalogId as CatalogSource, type, page, search);
  const metas: MetaPreview[] = [];
  const site = siteFromCatalogId(catalogId as CatalogSource);

  const resolvePromises = items.slice(0, PAGE_SIZE).map(async (item) => {
    try {
      const meta = await resolveImdbId(item.title, item.year, type);
      if (meta) {
        addImdbPageMapping(meta.id, {
          site,
          url: item.url,
          scraperTitle: item.title,
        });

        return {
          id: meta.id,
          type,
          name: meta.name,
          poster: meta.poster || item.poster,
          year: meta.year ? String(meta.year) : item.year,
          description: meta.description,
          genres: meta.genres,
          imdbRating: meta.imdbRating,
        } as MetaPreview;
      }
      return null;
    } catch (err) {
      logger.warn({ title: item.title, err }, "catalog item resolve failed");
      return null;
    }
  });

  const results = await Promise.allSettled(resolvePromises);
  for (const result of results) {
    if (result.status === "fulfilled" && result.value) {
      metas.push(result.value);
    }
  }

  const seen = new Set<string>();
  const uniqueMetas = metas.filter((m) => {
    if (seen.has(m.id)) return false;
    seen.add(m.id);
    return true;
  });

  const response = { metas: uniqueMetas };
  cache.set(cacheKey, response, TTL.CATALOG);
  return response;
}

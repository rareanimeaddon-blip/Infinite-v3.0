import axios from "axios";
import { getMetaFromCinemeta } from "../cinemeta.js";
import { getImdbPageMappings } from "./catalog.js";
import * as hub4k from "../scrapers/4khdhub.js";
import * as hdhub from "../scrapers/hdhub4u.js";
import { cache, TTL } from "../cache.js";
import { logger } from "../../lib/logger.js";

const VALIDATE_UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

interface StremioStream {
  name: string;
  title: string;
  url: string;
  behaviorHints?: {
    notWebReady?: boolean;
    proxyHeaders?: Record<string, Record<string, string>>;
  };
}

function buildStreamName(source: string, quality: string, language: string): string {
  return `${source}\n${quality} | ${language}`;
}

function buildStreamTitle(
  quality: string,
  language: string,
  host?: string,
): string {
  const parts = [quality, language];
  if (host) parts.push(`[${host}]`);
  return parts.join(" · ");
}

const DEAD_URL_PATTERNS = [
  "googleusercontent.com",
  "drive.google.com",
  "docs.google.com",
  "accounts.google.com",
];

function isKnownDeadUrl(url: string): boolean {
  const lower = url.toLowerCase();
  return DEAD_URL_PATTERNS.some((p) => lower.includes(p));
}

async function isStreamAlive(url: string): Promise<boolean> {
  if (isKnownDeadUrl(url)) return false;

  try {
    const res = await axios.get(url, {
      timeout: 6000,
      maxRedirects: 3,
      validateStatus: () => true,
      headers: {
        "User-Agent": VALIDATE_UA,
        "Range": "bytes=0-0",
        "Accept": "*/*",
      },
      responseType: "arraybuffer",
      maxContentLength: 2048,
    });

    if (res.status === 416) return true;
    if (res.status < 200 || res.status >= 400) return false;

    const ct = ((res.headers["content-type"] as string | undefined) ?? "").toLowerCase();
    if (ct.includes("application/json") || ct.includes("text/html")) {
      const body = Buffer.isBuffer(res.data)
        ? res.data.toString("utf8", 0, 512)
        : String(res.data ?? "").slice(0, 512);
      const lower = body.toLowerCase();
      if (
        lower.includes("quota") ||
        lower.includes("exceeded") ||
        lower.includes('"error"') ||
        lower.includes("access denied") ||
        lower.includes("forbidden") ||
        lower.includes("not found") ||
        lower.includes("<!doctype html") ||
        lower.includes("<html")
      ) {
        return false;
      }
    }

    return true;
  } catch {
    return false;
  }
}

async function validateStreams(streams: StremioStream[]): Promise<StremioStream[]> {
  if (streams.length === 0) return [];

  const results = await Promise.allSettled(
    streams.map(async (s) => ({ stream: s, alive: await isStreamAlive(s.url) })),
  );

  const alive: StremioStream[] = [];
  const dead: string[] = [];

  for (const r of results) {
    if (r.status === "fulfilled") {
      if (r.value.alive) {
        alive.push(r.value.stream);
      } else {
        dead.push(r.value.stream.url.slice(0, 80));
      }
    }
  }

  if (dead.length > 0) {
    logger.info({ total: streams.length, alive: alive.length, dead: dead.length }, "Stream validation complete");
  }

  return alive;
}

async function findPageUrls(
  imdbId: string,
  title: string,
  year: string | undefined,
  type: "movie" | "series",
): Promise<{ site: "4khdhub" | "hdhub4u"; url: string }[]> {
  const cacheKey = `streams:pages:${type}:${imdbId}`;
  const cached = cache.get<{ site: "4khdhub" | "hdhub4u"; url: string }[]>(cacheKey);
  if (cached) return cached;

  const pages: { site: "4khdhub" | "hdhub4u"; url: string }[] = [];

  const catalogMappings = getImdbPageMappings(imdbId);
  if (catalogMappings.length > 0) {
    logger.info({ imdbId, count: catalogMappings.length }, "Using catalog page mappings for streams");
    for (const m of catalogMappings) {
      pages.push({ site: m.site, url: m.url });
    }
    cache.set(cacheKey, pages, TTL.SEARCH);
    return pages;
  }

  const titleNorm = title.toLowerCase().replace(/[^a-z0-9]/g, "");

  const [hub4kResults, hdhubResults] = await Promise.allSettled([
    hub4k.searchSite(title),
    hdhub.searchSite(title),
  ]);

  if (hub4kResults.status === "fulfilled") {
    for (const item of hub4kResults.value.slice(0, 3)) {
      const itemNorm = item.title.toLowerCase().replace(/[^a-z0-9]/g, "");
      if (itemNorm.includes(titleNorm.slice(0, 6)) || titleNorm.includes(itemNorm.slice(0, 6))) {
        if (type === "movie" ? item.type === "movie" : true) {
          pages.push({ site: "4khdhub", url: item.url });
        }
      }
    }
  }

  if (hdhubResults.status === "fulfilled") {
    for (const item of hdhubResults.value.slice(0, 3)) {
      const itemNorm = item.title.toLowerCase().replace(/[^a-z0-9]/g, "");
      if (itemNorm.includes(titleNorm.slice(0, 6)) || titleNorm.includes(itemNorm.slice(0, 6))) {
        if (type === "movie" ? item.type === "movie" : true) {
          pages.push({ site: "hdhub4u", url: item.url });
        }
      }
    }
  }

  if (pages.length > 0) {
    cache.set(cacheKey, pages, TTL.SEARCH);
  }
  return pages;
}

export async function streamHandler(
  type: "movie" | "series",
  id: string,
): Promise<{ streams: StremioStream[] }> {
  const cacheKey = `streams:result:${type}:${id}`;
  const cached = cache.get<{ streams: StremioStream[] }>(cacheKey);
  if (cached) return cached;

  const streams: StremioStream[] = [];

  let imdbId = id;
  let season: number | undefined;
  let episode: number | undefined;

  if (type === "series" && id.includes(":")) {
    const parts = id.split(":");
    imdbId = parts[0]!;
    season = parseInt(parts[1] ?? "1");
    episode = parseInt(parts[2] ?? "1");
  }

  const meta = await getMetaFromCinemeta(type, imdbId);
  if (!meta) {
    logger.warn({ imdbId, type }, "Could not get meta from Cinemeta for stream");
    return { streams: [] };
  }

  const title = meta.name ?? "";
  const year = meta.year ? String(meta.year) : undefined;

  if (!title) {
    logger.warn({ imdbId, type }, "Cinemeta returned meta with no name, skipping");
    return { streams: [] };
  }

  logger.info({ imdbId, title, year, type, season, episode }, "Looking for streams");

  const pages = await findPageUrls(imdbId, title, year, type);

  if (pages.length === 0) {
    logger.warn({ imdbId, title, year }, "No pages found for title on either site");
    return { streams: [] };
  }

  const streamPromises = pages.map(async ({ site, url }) => {
    try {
      const entries = site === "4khdhub"
        ? await hub4k.extractStreams(url, season, episode)
        : await hdhub.extractStreams(url, season, episode);

      const sourceName = site === "4khdhub" ? "4KHDHub" : "HDHub4U";

      return entries.map((entry): StremioStream => ({
        name: buildStreamName(sourceName, entry.quality, entry.language),
        title: buildStreamTitle(entry.quality, entry.language, sourceName),
        url: entry.url,
        behaviorHints: {
          notWebReady: true,
        },
      }));
    } catch (err) {
      logger.warn({ site, url, err }, "Stream extraction failed");
      return [];
    }
  });

  const results = await Promise.allSettled(streamPromises);
  for (const result of results) {
    if (result.status === "fulfilled") {
      streams.push(...result.value);
    }
  }

  const seen = new Set<string>();
  const uniqueStreams = streams.filter((s) => {
    if (seen.has(s.url)) return false;
    seen.add(s.url);
    return true;
  });

  logger.info({ imdbId, title, total: uniqueStreams.length }, "Validating stream URLs");
  const validStreams = await validateStreams(uniqueStreams);

  const response = { streams: validStreams };
  if (validStreams.length > 0) {
    cache.set(cacheKey, response, TTL.STREAM);
  }
  return response;
}

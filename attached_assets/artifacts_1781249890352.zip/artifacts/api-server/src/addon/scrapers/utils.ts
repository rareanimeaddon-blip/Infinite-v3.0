import axios, { type AxiosRequestConfig } from "axios";
import * as cheerio from "cheerio";
import { logger } from "../../lib/logger.js";

const DEFAULT_HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
  Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
  "Accept-Language": "en-US,en;q=0.5",
  "Accept-Encoding": "gzip, deflate, br",
  Connection: "keep-alive",
};

export async function fetchHtml(
  url: string,
  extraHeaders?: Record<string, string>,
  config?: AxiosRequestConfig,
): Promise<cheerio.CheerioAPI | null> {
  try {
    const res = await axios.get<string>(url, {
      timeout: 15000,
      headers: { ...DEFAULT_HEADERS, ...extraHeaders },
      maxRedirects: 5,
      ...config,
    });
    return cheerio.load(res.data as string);
  } catch (err) {
    logger.warn({ url, err }, "fetchHtml failed");
    return null;
  }
}

export async function fetchText(
  url: string,
  extraHeaders?: Record<string, string>,
): Promise<string | null> {
  try {
    const res = await axios.get<string>(url, {
      timeout: 15000,
      headers: { ...DEFAULT_HEADERS, ...extraHeaders },
      maxRedirects: 5,
    });
    return res.data as string;
  } catch (err) {
    logger.warn({ url, err }, "fetchText failed");
    return null;
  }
}

export async function followRedirect(url: string): Promise<string | null> {
  try {
    const res = await axios.get<string>(url, {
      timeout: 10000,
      headers: DEFAULT_HEADERS,
      maxRedirects: 10,
    });
    return res.request?.res?.responseUrl ?? url;
  } catch {
    return null;
  }
}

export function cleanTitle(raw: string): string {
  return raw
    .replace(/\s+details\s*$/i, "")
    .replace(
      /\b(720p|1080p|2160p|480p|4k|webrip|web-dl|bluray|hdtc|hevc|x265|x264|avc|10bit|hdr|sdr|dv|dd[0-9.]+|aac|hindi|english|dual|multi|tamil|telugu|punjabi|season\s*\d+|s\d{2}|e\d{2}|full\s*(?:movie|series)|all\s*episodes?|webrip|remux)\b/gi,
      "",
    )
    .replace(/[-_]+/g, " ")
    .replace(/\s{2,}/g, " ")
    .trim();
}

export function extractYear(text: string): string | undefined {
  const m = text.match(/\b(19[5-9]\d|20[0-2]\d)\b/);
  return m ? m[1] : undefined;
}

export function extractQuality(text: string): string {
  if (/2160p|4k/i.test(text)) return "4K";
  if (/1080p/i.test(text)) return "1080p";
  if (/720p/i.test(text)) return "720p";
  if (/480p/i.test(text)) return "480p";
  return "HD";
}

export function extractLanguage(text: string): string {
  if (/dual[\s-]?audio|dual/i.test(text)) return "Dual Audio";
  if (/multi[\s-]?audio|multi/i.test(text)) return "Multi Audio";
  if (/hindi/i.test(text)) return "Hindi";
  if (/tamil/i.test(text)) return "Tamil";
  if (/telugu/i.test(text)) return "Telugu";
  if (/punjabi/i.test(text)) return "Punjabi";
  if (/english/i.test(text)) return "English";
  return "Hindi";
}

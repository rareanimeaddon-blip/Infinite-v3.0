import { catalogHandler } from "./handlers/catalog.js";
import { logger } from "../lib/logger.js";

interface WarmupEntry {
  type: "movie" | "series";
  id: string;
  skip?: number;
}

const PAGE_SIZE = 20;

const WARMUP_ENTRIES: WarmupEntry[] = [
  { type: "movie", id: "4khdhub_movies" },
  { type: "movie", id: "4khdhub_movies", skip: PAGE_SIZE },
  { type: "movie", id: "4khdhub_movies", skip: PAGE_SIZE * 2 },
  { type: "series", id: "4khdhub_series" },
  { type: "series", id: "4khdhub_series", skip: PAGE_SIZE },
  { type: "series", id: "4khdhub_series", skip: PAGE_SIZE * 2 },
  { type: "movie", id: "hdhub4u_movies" },
  { type: "series", id: "hdhub4u_series" },
];

export async function warmupCatalogs(): Promise<void> {
  logger.info("Warming up addon catalogs…");

  const results = await Promise.allSettled(
    WARMUP_ENTRIES.map(({ type, id, skip }) => {
      const extra: Record<string, string> = {};
      if (skip) extra["skip"] = String(skip);
      const page = skip ? Math.floor(skip / PAGE_SIZE) + 1 : 1;
      return catalogHandler(type, id, extra).then((r) => ({
        id,
        page,
        count: r.metas.length,
      }));
    }),
  );

  for (const result of results) {
    if (result.status === "fulfilled") {
      logger.info(
        { catalogId: result.value.id, page: result.value.page, items: result.value.count },
        "Catalog warmed up",
      );
    } else {
      logger.warn({ err: result.reason }, "Catalog warmup failed");
    }
  }

  logger.info("Addon catalog warmup complete");
}
